package herancas;

public class Estacionamento {
    
    public static void main(String[] args) {
        Carro gol = new Carro("Gol muito convervado", 1990 , "Azul", "G2", "Wolkswagen", 13999, false, false, 5, CambioEnum.MANUAL, CombustivelEnum.GASOLINA);
        System.out.println(gol);
        
        System.out.println("=====================================");
        
        Moto hornet = new Moto("Moto Hornet 600", 2014, "Preta", "Hornet", "Honda", 40000, true, true, CombustivelEnum.GASOLINA, PartidaEnum.PEDAL);
        System.out.println(hornet);
        
        System.out.println("=====================================");
        
        Scooter scooter = new Scooter(2200, "Scooter eletrica", 2023, "Cinza", "ELEKTRA", "Honda", 10000, true, false);
        System.out.println(scooter);
    }   
    
}
