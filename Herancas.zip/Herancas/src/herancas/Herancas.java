package herancas;

public class Herancas {

    public static void main(String[] args) {
        
    }
    
}
