package herancas.escola;

public class Pessoa implements ValidaPessoa {
    private String nome;
    private String email;
    private String sexualidade;
    private int idade;

    public Pessoa(String nome, String email, String sexualidade, int idade) {
        this.nome = nome;
        this.email = email;
        this.sexualidade = sexualidade;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSexualidade() {
        return sexualidade;
    }

    public int getIdade() {
        return idade;
    }

      
    public boolean verificarMaiorIdade() {
        if (this.idade >= 18) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + "Pessoa{" + "nome=" + nome + ", email=" + email + ", sexualidade=" + sexualidade + ", idade=" + idade + '}';
    }  

    @Override
    public String verificarDominioEmailGmail(String email) {
        String dominio = "";
        if (this.email.contains("@gmail")) {
            dominio = "@gmail";
        } else {
            dominio = "O dominio nao foi identificado ou e invalido";
        }
        return dominio;
    }
    
    @Override
    public String verificarDominioEmailYahoo(String email) {
        String dominio = "";
        if (this.email.contains("@yahoo")) {
            dominio = "@yahoo";
        } else {
            dominio = "O dominio nao foi identificado ou e invalido";
        }
        return dominio;
    }

}
