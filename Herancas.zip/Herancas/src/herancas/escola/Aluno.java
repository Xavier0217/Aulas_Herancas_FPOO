package herancas.escola;

public class Aluno extends Pessoa {
    private String ra;

    public Aluno(String ra, String nome, String email, String sexualidade, int idade) {
        super(nome, email, sexualidade, idade);
        this.ra = ra;
    }
    
    public int contagemCaracteresRa() {
        return this.ra.length();
    }

    @Override
    public boolean verificarMaiorIdade() {
        return super.verificarMaiorIdade();
    }

    
    
    @Override
    public String toString() {
        return super.toString() + "\n" + "ALuno{" + "ra=" + ra + '}';
    }
    
    
    
}
