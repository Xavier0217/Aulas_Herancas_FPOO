package herancas.escola;

public interface ValidaPessoa {
    
    String verificarDominioEmailGmail(String email);
    String verificarDominioEmailYahoo(String email);
}
