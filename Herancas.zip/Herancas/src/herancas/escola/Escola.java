package herancas.escola;

public class Escola {
    
    public static void main(String[] args) {
        
        
        Professor p1 = new Professor(true, "Moises Olimpo","Moises@gmail.com", "Homem", 40);
        System.out.println("=============================");
        System.out.println(p1);
        System.out.println("Dominio email: " + p1.verificarDominioEmailGmail(p1.getEmail()));
        System.out.println("Maior idade: " + p1.verificarMaiorIdade());
        System.out.println("Professor dedicado: " + p1.mensagemProfessorComDedicacao(p1.isDedicacaoExclusiva()));
        
        Aluno a1 = new Aluno("17X02", "Arthur Xavier","arthur.xavier016002@gmail.com", "Homem", 16);
        System.out.println("=============================");
        System.out.println(a1);
        System.out.println("Dominio email : " + a1.verificarDominioEmailGmail(a1.getEmail()));
        System.out.println("Maior idade: " + a1.verificarMaiorIdade());
        System.out.println("Quantidade de caracteres no ra: " + a1.contagemCaracteresRa());
        
        Professor p2 = new Professor(false, "Marcio", "marcio@yahoo.com", "Homem", 47);
        System.out.println("=============================");
        System.out.println(p2);
        System.out.println("Dominio email: " + p2.verificarDominioEmailYahoo(p2.getEmail()));
        System.out.println("Maior idade: " + p2.verificarMaiorIdade());
        System.out.println("Professor dedicado: " + p2.mensagemProfessorComDedicacao(p2.isDedicacaoExclusiva()));
        
        Aluno a2 = new Aluno("16Z03", "Joao", "joao@yahoo.com", "Homem", 16);
        System.out.println("=============================");
        System.out.println(a2);
        System.out.println("Dominio email: " + a2.verificarDominioEmailYahoo(a2.getEmail()));
        System.out.println("Maior idade: " + a2.verificarMaiorIdade());
        System.out.println("Quantidade de caracteres no ra: " + a2.contagemCaracteresRa());
        
    }
    
}
