package herancas.escola;

public class Professor extends Pessoa {
    
    private boolean dedicacaoExclusiva;

    public boolean isDedicacaoExclusiva() {
        return dedicacaoExclusiva;
    }


    public Professor(boolean dedicacaoExclusiva, String nome, String email, String sexualidade, int idade) {
        super(nome, email, sexualidade, idade);
        this.dedicacaoExclusiva = dedicacaoExclusiva;
    }

    public String mensagemProfessorComDedicacao(boolean dedicacaoExclusiva) {
        String mensagem = "";
        if (this.dedicacaoExclusiva) {
            mensagem = "O professor e dedicado";
        } else {
            mensagem = "O professor nao e dedicado";
        }
        return mensagem;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + "Professor{" + "dedicacaoExclusiva=" + dedicacaoExclusiva + '}';
    }
    
    
    
    
}
