package herancas;

public enum CombustivelEnum {
    GASOLINA("Gasolina"),
    ETANOL("Estanol"),
    DIESEL("Diesel"),
    GNV("Gás natural veicular");
    
    private String tipoCombustivel;

    private CombustivelEnum(String tipoCombustivel) {
        this.tipoCombustivel = tipoCombustivel;
    }

    public String getTipoCombustivel() {
        return tipoCombustivel;
    }
    
}
